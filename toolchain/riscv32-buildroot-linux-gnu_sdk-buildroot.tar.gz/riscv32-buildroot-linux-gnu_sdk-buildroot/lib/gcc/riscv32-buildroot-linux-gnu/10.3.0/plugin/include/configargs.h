/* Generated automatically. */
static const char configuration_arguments[] = "./configure --prefix=/home/hd/hacking/Icebreaker/iCE40linux/firmware/buildroot/output/host --sysconfdir=/home/hd/hacking/Icebreaker/iCE40linux/firmware/buildroot/output/host/etc --enable-static --target=riscv32-buildroot-linux-gnu --with-sysroot=/home/hd/hacking/Icebreaker/iCE40linux/firmware/buildroot/output/host/riscv32-buildroot-linux-gnu/sysroot --enable-__cxa_atexit --with-gnu-ld --disable-libssp --disable-multilib --disable-decimal-float --with-gmp=/home/hd/hacking/Icebreaker/iCE40linux/firmware/buildroot/output/host --with-mpc=/home/hd/hacking/Icebreaker/iCE40linux/firmware/buildroot/output/host --with-mpfr=/home/hd/hacking/Icebreaker/iCE40linux/firmware/buildroot/output/host --with-pkgversion='Buildroot 2021.08-271-g2c5e13de7c' --with-bugurl=http://bugs.buildroot.net/ --without-zstd --disable-libquadmath --disable-libquadmath-support --enable-tls --enable-threads --without-isl --without-cloog --with-arch=rv32ia --with-abi=ilp32 --enable-languages=c --with-build-time-tools=/home/hd/hacking/Icebreaker/iCE40linux/firmware/buildroot/output/host/riscv32-buildroot-linux-gnu/bin --enable-shared --disable-libgomp";
static const char thread_model[] = "posix";

static const struct {
  const char *name, *value;
} configure_default_options[] = { { "abi", "ilp32" }, { "arch", "rv32ia" } };
